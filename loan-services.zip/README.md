# Loan Services — Full GitHub Project

Full-stack Loan Services example: FastAPI backend + React frontend, Dockerized, with tests and CI.

## Quick start

1. Backend:
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

2. Frontend:
```bash
cd frontend
npm install
npm run dev
```

Or with Docker Compose:
```bash
docker-compose up --build
```

## Structure
```
loan-services/
├── backend/
│   ├── app/
│   │   ├── main.py
│   │   ├── models.py
│   │   ├── schemas.py
│   │   ├── database.py
│   │   ├── crud.py
│   │   ├── auth.py
│   │   └── routers/
│   │       ├── auth.py
│   │       └── loans.py
│   └── requirements.txt
├── frontend/
│   ├── package.json
│   └── src/
│       └── App.jsx
├── docker-compose.yml
└── README.md
```

See the included code files for full implementation.
