from sqlmodel import Session, select
from . import models

def create_user(session: Session, email: str, hashed_password: str, is_admin: bool = False):
    user = models.User(email=email, hashed_password=hashed_password, is_admin=is_admin)
    session.add(user)
    session.commit()
    session.refresh(user)
    return user

def get_user_by_email(session: Session, email: str):
    return session.exec(select(models.User).where(models.User.email == email)).first()

def create_loan(session: Session, applicant_id: int, amount: float, term_months: int, purpose: str | None):
    loan = models.Loan(applicant_id=applicant_id, amount=amount, term_months=term_months, purpose=purpose)
    session.add(loan)
    session.commit()
    session.refresh(loan)
    return loan

def get_loans_for_user(session: Session, user_id: int):
    return session.exec(select(models.Loan).where(models.Loan.applicant_id == user_id)).all()

def get_all_loans(session: Session):
    return session.exec(select(models.Loan)).all()

def update_loan_status(session: Session, loan_id: int, status: str):
    loan = session.get(models.Loan, loan_id)
    if not loan:
        return None
    loan.status = status
    session.add(loan)
    session.commit()
    session.refresh(loan)
    return loan
