from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlmodel import Session
from .. import database, crud, auth, schemas

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post('/register', response_model=schemas.UserRead)
def register(user: schemas.UserCreate):
    with Session(database.engine) as session:
        existing = crud.get_user_by_email(session, user.email)
        if existing:
            raise HTTPException(status_code=400, detail="Email already registered")
        hashed = auth.get_password_hash(user.password)
        new_user = crud.create_user(session, user.email, hashed)
        return schemas.UserRead.from_orm(new_user)

@router.post('/token', response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    with Session(database.engine) as session:
        user = auth.authenticate_user(session, form_data.username, form_data.password)
        if not user:
            raise HTTPException(status_code=400, detail="Incorrect username or password")
        access_token = auth.create_access_token({"sub": str(user.id)})
        return {"access_token": access_token, "token_type": "bearer"}
