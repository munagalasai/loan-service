from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session
from .. import database, schemas, crud, auth

router = APIRouter(prefix="/loans", tags=["loans"])

@router.post('/', response_model=schemas.LoanRead)
def apply_loan(payload: schemas.LoanCreate, user: auth.get_current_user = Depends(auth.get_current_user)):
    with Session(database.engine) as session:
        loan = crud.create_loan(session, user.id, float(payload.amount), payload.term_months, payload.purpose)
        return schemas.LoanRead.from_orm(loan)

@router.get('/', response_model=list[schemas.LoanRead])
def get_my_loans(user: auth.get_current_user = Depends(auth.get_current_user)):
    with Session(database.engine) as session:
        loans = crud.get_loans_for_user(session, user.id)
        return [schemas.LoanRead.from_orm(l) for l in loans]

@router.get('/admin', response_model=list[schemas.LoanRead])
def get_all_loans(admin=Depends(auth.get_current_admin)):
    with Session(database.engine) as session:
        loans = crud.get_all_loans(session)
        return [schemas.LoanRead.from_orm(l) for l in loans]

@router.post('/{loan_id}/status', response_model=schemas.LoanRead)
def change_status(loan_id: int, status: str, admin=Depends(auth.get_current_admin)):
    with Session(database.engine) as session:
        loan = crud.update_loan_status(session, loan_id, status)
        if not loan:
            raise HTTPException(status_code=404, detail="Loan not found")
        return schemas.LoanRead.from_orm(loan)
