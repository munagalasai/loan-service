from pydantic import BaseModel, EmailStr, condecimal, PositiveInt
from typing import Optional

class UserCreate(BaseModel):
    email: EmailStr
    password: str

class UserRead(BaseModel):
    id: int
    email: EmailStr
    is_admin: bool

class LoanCreate(BaseModel):
    amount: condecimal(gt=0)
    term_months: PositiveInt
    purpose: Optional[str]

class LoanRead(BaseModel):
    id: int
    applicant_id: int
    amount: float
    term_months: int
    purpose: Optional[str]
    status: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
