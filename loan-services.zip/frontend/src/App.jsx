import React, { useState, useEffect } from 'react';
import axios from 'axios';
const API = axios.create({ baseURL: 'http://localhost:8000' });

export default function App(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState('');
  const [amount, setAmount] = useState('');
  const [loans, setLoans] = useState([]);

  async function register(){
    await API.post('/auth/register', { email, password });
    alert('registered');
  }
  async function login(){
    const form = new URLSearchParams();
    form.append('username', email);
    form.append('password', password);
    const res = await API.post('/auth/token', form);
    setToken(res.data.access_token);
    API.defaults.headers.common['Authorization'] = `Bearer ${res.data.access_token}`;
  }
  async function apply(){
    await API.post('/loans', { amount, term_months: 12 });
    fetchLoans();
  }
  async function fetchLoans(){
    const res = await API.get('/loans');
    setLoans(res.data);
  }

  useEffect(()=>{ if(token) fetchLoans(); }, [token]);

  return (
    <div style={{padding:20}}>
      <h1>Loan Services</h1>
      <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={register}>Register</button>
      <button onClick={login}>Login</button>

      <hr />
      <h2>Apply Loan</h2>
      <input placeholder="amount" value={amount} onChange={e=>setAmount(e.target.value)} />
      <button onClick={apply}>Apply</button>

      <h3>My Loans</h3>
      <ul>{loans.map(l => <li key={l.id}>{l.amount} - {l.status}</li>)}</ul>
    </div>
  )
}
